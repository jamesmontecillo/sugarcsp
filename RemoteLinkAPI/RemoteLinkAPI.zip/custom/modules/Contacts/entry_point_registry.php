 <?php
$entry_point_registry["customPortalUserCreate"]=array("file"=>"custom/modules/Contacts/customPortalUserCreate.php","auth"=>false);
?>
